# Farmear Aura 3D

Juego 3D sencillo para navegador, diseñado para controles táctiles en teléfono.

## Cómo jugar
- Toca **JUGAR**.
- Usa las flechas de la pantalla para moverte.
- Pulsa **SALTAR** para brincar.
- Acércate a una esfera azul y pulsa **FARMEAR AURA** para recogerla (+5 aura).
- Sube de rango y bate tu récord.

También funciona con WASD/flechas del teclado y barra espaciadora para saltar.

## Ejecutarlo
El juego carga Three.js desde jsDelivr, por lo que necesita internet.

### Opción rápida: GitHub Pages desde el teléfono
1. Abre https://github.com/new e inicia sesión.
2. Crea un repositorio público llamado `farmear-aura-3d`.
3. En el repositorio, pulsa **Add file → Upload files**.
4. Descomprime este ZIP primero si GitHub no te deja seleccionar `index.html` directamente; sube `index.html` y `README.md`.
5. Pulsa **Commit changes**.
6. En el repositorio, abre **Settings → Pages**.
7. En **Build and deployment**, elige **Deploy from a branch**.
8. Selecciona la rama `main` y la carpeta `/(root)`, y pulsa **Save**.
9. Espera un momento y vuelve a Settings → Pages. Abre el enlace que aparece; tendrá una forma parecida a `https://TU-USUARIO.github.io/farmear-aura-3d/`.

### Importante
- El enlace exacto depende de tu usuario de GitHub y no se puede adivinar.
- Si ves una pantalla en blanco, revisa que el archivo se llame exactamente `index.html`, que haya internet y que el navegador permita WebGL.
- El juego guarda tu récord en el almacenamiento local del navegador del teléfono.
